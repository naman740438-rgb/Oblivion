import os 

TOKEN =os .environ .get ("TOKEN")
NAME ="Oblivion-bot"
server ="https://discord.gg/JxCFmz9nZP"
ch ="https://discord.com/channels/1324668335069331477/1324668336470102143"
OWNER_IDS =[1124248109472550993 ,1366749025814052895 ,1198187445859139595 ]
BotName ="Oblivion-bot"
serverLink ="https://discord.gg/JxCFmz9nZP"
"""
: ! Aegis !
    + Discord: root.exe
    + Community: https://discord.gg/meet (Vortex Development )
    + for any queries reach out Community or DM me.
"""
