import discord 
from discord .ext import commands 


class _fun (commands .Cog ):
    def __init__ (self ,bot ):
        self .bot =bot 

    """Fun commands"""

    def help_custom (self ):
		      emoji ='<:icon_Extra:1372375162640535653>'
		      label ="Fun Commands"
		      description =""
		      return emoji ,label ,description 

    @commands .group ()
    async def __Fun__ (self ,ctx :commands .Context ):
        """`mydog` , `chat` , `translate` , `howgay` , `lesbian` , `cute` , `intelligence` , `horny` , `gif` , `iplookup` , `weather` , `hug` , `kiss` , `pat` , `cuddle` , `slap` , `tickle` , `spank` , `ngif` , `8ball` , `truth` , `dare`"""
"""
: ! Aegis !
    + Discord: root.exe
    + Community: https://discord.gg/meet (Vortex Development )
    + for any queries reach out Community or DM me.
"""
