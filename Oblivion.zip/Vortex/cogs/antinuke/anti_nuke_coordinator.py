

pass 
"""
: ! Aegis !
    + Discord: root.exe
    + Community: https://discord.gg/meet (Vortex Development )
    + for any queries reach out Community or DM me.
"""
