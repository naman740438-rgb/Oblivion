from __future__ import annotations 

from discord .ext import commands 
import discord 
import functools 
from typing import Optional ,Any 
import asyncio 

__all__ =("Context",)


class Context (commands .Context ):

    def __init__ (self ,*args ,**kwargs )->None :
        super ().__init__ (*args ,**kwargs )

    def __repr__ (self ):
        return "<core.Context>"

    @property 
    async def session (self ):
        return self .bot .session 

    @discord .utils .cached_property 
    def replied_reference (self )->Optional [discord .Message ]:
        ref =self .message .reference 
        if ref and isinstance (ref .resolved ,discord .Message ):
            return ref .resolved .to_reference ()
        return None 

    def with_type (func ):

        @functools .wraps (func )
        async def wrapped (self ,*args ,**kwargs ):
            context =args [0 ]if isinstance (args [0 ],
            commands .Context )else args [1 ]
            try :
                async with context .typing ():
                    await func (*args ,**kwargs )
            except discord .Forbidden :
                await func (*args ,**kwargs )

        return wrapped 

    async def show_help (self ,command :str =None )->Any :
        cmd =self .bot .get_command ('help')
        command =command or self .command .qualified_name 
        await self .invoke (cmd ,command =command )

    async def send_help (self ,command =None )->Any :
        """Alternative method name for consistency"""
        return await self .show_help (command )

    async def send (self ,
    content :Optional [str ]=None ,
    **kwargs )->Optional [discord .Message ]:
        if not (self .channel .permissions_for (self .me )).send_messages :
            try :
                await self .author .send (
                "Bot doesn't have permission to send messages in that channel.")
            except discord .Forbidden :
                pass 
            return 
        try :
            return await super ().send (content ,**kwargs )
        except discord .HTTPException :

            return None 

    async def reply (self ,
    content :Optional [str ]=None ,
    **kwargs )->Optional [discord .Message ]:
        if not (self .channel .permissions_for (self .me )).send_messages :
            try :
                await self .author .send (
                "Bot doesn't have permission to send messages in that channel.")
            except discord .Forbidden :
                pass 
            return 
        try :
            return await super ().reply (content ,**kwargs )
        except discord .HTTPException :

            return None 

    async def release (self ,delay :Optional [int ]=None )->None :
        delay =delay or 0 
        await asyncio .sleep (delay )

"""
: ! Aegis !
    + Discord: root.exe
    + Community: https://discord.gg/meet (Vortex Development )
    + for any queries reach out Community or DM me.
"""
